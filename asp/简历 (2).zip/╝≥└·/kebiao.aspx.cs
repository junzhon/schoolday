﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class 简历_kebiao : System.Web.UI.Page
{
    protected void BtnMove_Click(object sender, EventArgs e)
    {
        for (int i = 0; i < lstLeft.Items.Count; i++)  //遍历左边列表框中所有项
        {
            if (lstLeft.Items[i].Selected)  //判断数据项是否选中
            {
                lstRight.Items.Add(lstLeft.Items[i]);  //向右边列表框添加选中的一项
              // Response.Redirect("../简历/dongtaibiao.aspx?pwd=" + lstLeft.Items[i]);
                Server.Execute("../简历/dongtaibiao.aspx?pwd=" + lstLeft.Items[i]);
              //  Server.Transfer("../简历/dongtaibiao.aspx?pwd=" + lstLeft.Items[i]);
                lstLeft.Items.Remove(lstLeft.Items[i]);
                
                i--;  //调整左边列表框中剩余项索引号
            }
        }
        
    }
}