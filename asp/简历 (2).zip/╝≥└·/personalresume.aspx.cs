﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



public partial class 简历_personalresume : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = Request.QueryString["id"];
       
        if (!IsPostBack)  //页面第一次载入时向各下拉列表框填充数据
        {
            BindYear();  //调用自定义方法BindYear()向“年份”下拉列表框填充数据
            BindMonth();  //调用自定义方法BindMonth()向“月份”下拉列表框填充数据
            BindDay();  //调用自定义方法BindDay()向“日期”下拉列表框填充数据
        }
        //if (Server.UrlDecode(lblmsg.Text)!="Null")
        //{
        //    Response.Write("<script>window.close();</script>");
        //}
    }

    protected void BindYear()
    {
        ddlYear.Items.Clear();  //清空ddlYear
        int startYear = DateTime.Now.Year - 20;
        int currentYear = DateTime.Now.Year;
        for (int i = startYear; i <= currentYear; i++)  //向ddlYear添加最近十年的年份
        {
            ddlYear.Items.Add(new ListItem(i.ToString()));
        }
        ddlYear.SelectedValue = 2002.ToString();  //设置ddlYear的默认项
    }
    protected void BindMonth()
    {
        ddlMonth.Items.Clear();
        for (int i = 1; i <= 12; i++)  //向ddlMonth添加一年的月份
        {
            ddlMonth.Items.Add(i.ToString());
        }
        ddlMonth.SelectedValue = 3.ToString();
    }
    protected void BindDay()
    {
        ddlDay.Items.Clear();
        string year = ddlYear.SelectedValue;  //获取ddlYear中选定项的值
        string month = ddlMonth.SelectedValue;
        int days = DateTime.DaysInMonth(int.Parse(year), int.Parse(month));  //获取相应年、月对应的天数    
        for (int i = 1; i <= days; i++)  //向ddlDay添加相应年、月对应的天数
        {
            ddlDay.Items.Add(i.ToString());
        }
        ddlDay.SelectedValue = 14.ToString();
    }
    protected void DdlYear_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindDay();
    }
    protected void DdlMonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindDay();
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
       // Response.Redirect("../简历/ans.aspx?name2=" + lblmsg.Text);
       // Response.Redirect("../简历/ans.aspx?name="+lblmsg.Text+"&&phone="+TextBox1.Text+"&&mailbox="+TextBox2.Text+"&&hobby="+ chklsSport.SelectedValue+"&&gender="+rbl1.SelectedValue+"&&birth="+ ddlYear.SelectedValue+"."+ddlMonth.SelectedValue+"."+ddlDay.SelectedValue);
       // Response.Redirect("../简历/ans.aspx?phone=" + TextBox1.Text);
       //  Response.Redirect("../简历/ans.aspx?mailbox=" + TextBox2.Text);
       // Response.Redirect("../简历/ans.aspx?hobby=" + chklsSport.SelectedValue);
       // Response.Redirect("../简历/ans.aspx?gender=" + rbl1.SelectedValue);
       // Response.Redirect("../简历/ans.aspx?birth=" + ddlYear.SelectedValue);

    }

    protected void clos(object sender, EventArgs e)
    {
        Response.End();
    }
    /*
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                HttpPostedFile file = image1.PostedFile;//对应前端file控件的id
                if (file != null && file.ContentLength > 0)
                {
                    string fileName = file.FileName;
                    string fileSize = file.ContentLength.ToString();
                    string fileType = file.ContentType;
                    string fileExtension = Path.GetExtension(fileName);
                    if (fileExtension == null || fileExtension.Trim() == "")
                    {
                        fileExtension = "";
                    }
                    else
                    {
                        if (fileExtension.IndexOf('.') == -1)
                        {
                            fileExtension = "." + fileExtension;
                        }
                    }
                    string filePath = "/image1" + "/" + Guid.NewGuid().ToString() + fileExtension;

                    Stream stream = file.InputStream;//文件流

                    FileUploadClass upload = new FileUploadClass();//上传类，自己写就可以
                    upload.UploadFile(stream, filePath);//上传文件
                    stream.Close();
                }
            }
            catch (Exception ee)
            {
            }

        }
    
    public static string CharAt(this string s, int index)
    {
                   if ((index >= s.Length) || (index < 0))
                          return "";
                   return s.Substring(index, 1);
               }
    public static int parseInt(String str)
    {
        int sum = 0;
        for(int i = 0; i < str.Length; i++){
            sum = sum*10 + str.CharAt(str,str.Length-1) - '0';
        }
        return sum;
      
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        //获得图象并把图象转换为byte[]
        HttpPostedFile upPhoto = UpPhoto.PostedFile;
        int upPhotoLength = upPhoto.ContentLength;
        string[] PhotoArray = new string[upPhotoLength];
        Stream PhotoStream = upPhoto.InputStream;
        Response.Write(PhotoStream);
        //PhotoStream.Read(PhotoArray, 0, upPhotoLength);

        //连接数据库
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = "Server=tcp:35.database.windows.net,1433;Initial Catalog=Repo;Persist Security Info=False;User ID=jjfly;Password=233123321q@;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        int ii =int.Parse(Label1.Text.Trim());
        //
        string strSql = "Insert into detail(img,Id) values('@FImage','" + ii + "')";
        SqlCommand cmd=new SqlCommand(strSql,conn);
        cmd.Parameters.Add("@FImage",SqlDbType.Image);
        cmd.Parameters["@FImage"].Value=PhotoArray;

        conn.Open();
        cmd.ExecuteNonQuery();
        conn.Close();
    }*/

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (upload1.HasFile)//判断控件是否有文件路径
                            {
                                string filename = upload1.FileName;//取得文件名
                                 filename = filename.Substring(filename.LastIndexOf(".") + 1);//取得后缀
                                 if (filename.ToLower() == "jpg" || filename.ToLower() == "gif")//判断类型
                                     {
                                         string img = DateTime.Now.ToString("yyyyMMddHHmmssfff") + "." + filename;
                                         upload1.SaveAs(Server.MapPath("Image/") + img);
                                         string picture = ("Image/") + img;
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = "Server=tcp:35.database.windows.net,1433;Initial Catalog=Repo;Persist Security Info=False;User ID=jjfly;Password=233123321q@;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
                int ii = int.Parse(Label1.Text.Trim());
                //
                Response.Write(picture);
                string ck=null;
                foreach (ListItem listItem in chklsSport.Items)
                {
                    if (listItem.Selected)
                    {
                        ck = ck + listItem.Text;
                    }
                }
                string strSql = "Insert into detail2(img,Id,num,birth,phone,mail,hobby,sex) values('" +picture+ "','" + ii + "','" + TextBox3.Text + "','" + ddlYear.SelectedValue+ddlMonth.SelectedValue+ddlDay.SelectedValue + "','" + TextBox1.Text + "','" + TextBox2.Text + "',N'" + ck + "',N'" + rbl1.SelectedValue + "')";
                SqlCommand cmd = new SqlCommand(strSql, conn);
                conn.Open();
             int result2 =(int)cmd.ExecuteNonQuery();
                
                //传到根目录的images文件夹+重命名的文件名，也可以用原来的图片的名称，自己定。上传成功；

                
                conn.Close();
                                         if (result2 == 1) { }
                                               
                                         else if (result2 != 1)
                                             {
                                                 Response.Write("<script>alert('注册失败！');</script>");
                                                return;
                                            }
                                     }
                                 else
                     {
                                         Response.Write("<script>alert('图片格式只支持jpg和gif');</script>");
                                         return;//提示错误
                                     }
                             }
                         else
                 {
                                 Response.Write("<script>alert('请选相片！');</script>");
                                 return;//提示错误
                             }
    }
}

