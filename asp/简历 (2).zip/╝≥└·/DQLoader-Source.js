﻿
/*
 * DQLoader.js 地区加载
 * Copyright 2010 OPS,All rights reseved!
 * author : newmin  http://b.ops.cc
 * date   : 2010/11/25
 */
 
 var _script=document.createElement("script");
 _script.type="text/javascript";
 _script.src="DQdata.js";
 var _$header=document.getElementsByTagName("head")[0];
 _$header.insertBefore(_script,_$header.childNodes[0]);
 
/* USE Global variable DQdata; */
function DQLoader(data){
 /*
  * data format:{pe:*,ce:*,ae:*,value:'',defaultText:'请选择',func}
  * pe:province element
  * ce:city element
  * ae:area element
  */
 this.pe=data.pe;
 this.ce=data.ce;
 this.ae=data.ae;
 this.defaultText=data.defaultText;
 this.data=data.data;
 this.func=data.func;
}
DQLoader.prototype.init=function(){
       var  _t=this;
        /************* 定义填充Dom方法 ************************/
       var fill=function(elem,data){
                /* 添加dom方法 */
                var f=function(value,text){
                    var opt=document.createElement("option");
                    opt.setAttribute("value",value);
                    opt.innerHTML=text;
                    elem.appendChild(opt);
                };
                /* 清空option */
                elem.innerHTML="";
                /* 加载默认值 */
                if(_t.defaultText){f('',_t.defaultText);}
                /* 加载数据 */
                for(var i in data)f(data[i].id,data[i].name);
        };
        /*********** 为Elements添加onchange事件****************/ 
        this.pe.onchange=function(){fill(_t.ce,_t.defaultText&&this.selectedIndex==0?null:DQdata[_t.defaultText?this.selectedIndex-1:this.selectedIndex].citys); _t.ce.onchange();};
        this.ce.onchange=function(){fill(_t.ae,_t.defaultText&&this.selectedIndex==0?null:DQdata[_t.defaultText?_t.pe.selectedIndex-1:_t.pe.selectedIndex].citys[_t.defaultText?this.selectedIndex-1:this.selectedIndex].dis);_t.ae.onchange();};
        this.ae.onchange=function(){
            if(_t.func){
                /* 获取选择的结果 */
                var result={
                pid:_t.pe.options[_t.pe.selectedIndex].value,
                pname:_t.pe.options[_t.pe.selectedIndex].innerHTML,
                cid:_t.ce.options[_t.ce.selectedIndex].value,
                cname:_t.ce.options[_t.ce.selectedIndex].innerHTML,
                aid:_t.ae.options[_t.ae.selectedIndex].value,
                aname:_t.ae.options[_t.ae.selectedIndex].innerHTML
                };
                _t.func(result);
            }
        };
        /************* 初始化数据 *********************/
        fill(this.pe,DQdata);
        if(!this.data)this.pe.onchange();
        else{
            for(var i=0;i<DQdata.length;i++){
                /* 设置pe状态 */
                if(this.data[0]==DQdata[i].name){
                    this.pe.value=DQdata[i].id;
                    this.pe.onchange();
                    /* 设置ce状态 */
                    for(var j=0;j<DQdata[i].citys.length;j++){ 
                      if(this.data[1]==DQdata[i].citys[j].name){
                        this.ce.value=DQdata[i].citys[j].id;
                        this.ce.onchange();
                         /* 设置ae状态 */
                        for(var k=0;k<DQdata[i].citys[j].dis.length;k++){
                            if(this.data[2]==DQdata[i].citys[j].dis[k].name){
                                this.ae.value=DQdata[i].citys[j].dis[k].id;
                                this.ae.onchange();
                            }
                        }
                       }
                    }
                }
            }
        }
        
}