﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Text.RegularExpressions;

public partial class 简历_dongtaibiao : System.Web.UI.Page
{
    
    protected void Page_Load1(object sender, EventArgs e)
    {
        string[] name = { "钟俊", "李四" };  //设置姓名初使值，实际工程中数据来源于数据库
        string[] number = { "222","333"};  //设置学号初使值          
        string[] pwd = new string[999];
        for (int i = 1; i <= 2; i++) pwd[i] = Request.QueryString["pwd"];
        for (int i = 1; i <= 2; i++)  //动态生成表格
        {
            TableRow row = new TableRow();  //建立一个行对象        
            TableCell cellNumber = new TableCell();  //建立第一个单元格对象     
            TableCell cellName = new TableCell();  //建立第二个单元格对象
            TableCell cellInput = new TableCell();  //建立第三个单元格对象  
            
           // Response.Write(cellInput.Text);
            cellNumber.Text = number[i - 1];  //设置第一个单元格的显示内容
            cellName.Text = name[i - 1];  //设置第二个单元格的显示内容  
            //cellInput.Text = Request.QueryString["pwd"];
            cellInput.Text = pwd[i];
            //TextBox txtInput = new TextBox();  //建立一个文本框对象        
            //  cellInput.Controls.Add(txtInput);  //添加文本框对象到第三个单元格中
            row.Cells.Add(cellNumber); //添加第一个单元格到行对象
            row.Cells.Add(cellName);  //添加第二个单元格到行对象
            row.Cells.Add(cellInput);  //添加第三个单元格到行对象
            tblScore.Rows.Add(row);  //添加行对象到表格对象
        }
    }
}

