﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class 简历_ans : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (PreviousPage.IsCrossPagePostBack)
        {
            
            TextBox TextBox4 = (TextBox)PreviousPage.FindControl("TextBox4");
            lblMsg.Text += "姓名：" + TextBox4.Text + "<br />";

            RadioButtonList rbl1 = (RadioButtonList)PreviousPage.FindControl("rbl1");
            lblMsg.Text += "性别：" + rbl1.Text + "<br />";

            DropDownList ddlYear = (DropDownList)PreviousPage.FindControl("ddlYear");
            DropDownList ddlMonth = (DropDownList)PreviousPage.FindControl("ddlMonth");
            DropDownList ddlDay = (DropDownList)PreviousPage.FindControl("ddlDay");
            lblMsg.Text += "出生年月日：" + ddlYear.Text + "年" + ddlMonth.Text + "月" + ddlDay.Text + "日" + "<br />";

            TextBox TextBox3 = (TextBox)PreviousPage.FindControl("TextBox3");
            lblMsg.Text += "学号：" + TextBox3.Text + "<br />";

            TextBox TextBox2 = (TextBox)PreviousPage.FindControl("TextBox2");
            lblMsg.Text += "邮箱：" + TextBox2.Text + "<br />";

            TextBox TextBox1 = (TextBox)PreviousPage.FindControl("TextBox1");
            lblMsg.Text += "电话号码：" + TextBox1.Text + "<br />";

            CheckBoxList chklsSport = (CheckBoxList)PreviousPage.FindControl("chklsSport");
            lblMsg.Text += "爱好：";
            foreach (ListItem listItem in chklsSport.Items)
            {
                if (listItem.Selected)
                {
                    lblMsg.Text = lblMsg.Text + listItem.Text + "&nbsp";
                }
            }

         
        }

    }
}