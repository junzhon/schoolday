﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class 简历_register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = Application["VisitNumber"].ToString();  //显示网站在线人数
        lblMsg2.Text= Application["totalnumber"].ToString();
    }
   
    protected void btnregister_Click(object sender, EventArgs e)
    {
        HttpCookie cookie = new HttpCookie("users");
        cookie.Value = System.Web.HttpContext.Current.Server.UrlEncode(txtuname.Text);
        cookie.Expires = DateTime.Now.AddDays(1);
        Response.Cookies.Add(cookie);
        string strconn = "Server=tcp:35.database.windows.net,1433;Initial Catalog=Repo;Persist Security Info=False;User ID=jjfly;Password=233123321q@;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
       string strcmd = "insert info(name,pwd) values(N'"+txtuname.Text+"','"+ Server.UrlEncode(txtpwd.Text)+ "');SELECT @@IDENTITY AS 'Identity'";//Server.UrlEncode()防注入

        SqlConnection conn = new SqlConnection(strconn);
        SqlCommand cmd = new SqlCommand(strcmd, conn);
        conn.Open();
        object j=cmd.ExecuteScalar();
        
        
         Response.Write("<script>alert('注册成功')</script>");
        conn.Close();
        Server.Transfer("../简历/login.aspx?id="+j);

    }

    protected void btnreset_Click(object sender, EventArgs e)
    {
        txtuname.Text = "";
        txtpwd.Text = "";
        txtnpwd.Text = "";
    }
    protected void BtnAll_Click(object sender, EventArgs e)
    {
        mysqlDataContext db = new mysqlDataContext();  //定义mysqlDataContext类实例db
        var products = from r in db.info  //db是公共的mysqlDataContext类实例
                       select r;
        gv.DataSource = products;  //将LINQ查询结果设置为gv的数据源
        gv.DataBind();  //显示数据源中的数据
    }
    protected void BtnProject_Click(object sender, EventArgs e)
    {
        mysqlDataContext db = new mysqlDataContext();  //定义mysqlDataContext类实例db
        var products = from r in db.info  //db是公共的mysqlDataContext类实例
                       select new
                       {
                           r.Id,
                           r.name,
   
                          
                       };
        gv.DataSource = products;
        gv.DataBind();
    }
    protected void BtnSelect_Click(object sender, EventArgs e)
    {
        mysqlDataContext db = new mysqlDataContext();
        var products = from r in db.info
                       where r.Id > 10
                       select r;
        gv.DataSource = products;
        gv.DataBind();
    }
    protected void BtnOrder_Click(object sender, EventArgs e)
    {
        mysqlDataContext db = new mysqlDataContext();
        var results = from r in db.info
                      orderby r.Id descending
                      select r;
        gv.DataSource = results;
        gv.DataBind();
    }
    protected void BtnGroup_Click(object sender, EventArgs e)
    {
        mysqlDataContext db = new mysqlDataContext();
        //根据CategoryId分组，再将结果存入results
        var results = from r in db.info
                      group r by r.Id;
        foreach (var g in results)  //results为外集合，g为外集合中的一个元素并且g也是一个集合
        {
            if (g.Key == 5)  //获取键值等于5的外集合元素
            {
                var results2 = from r in g  //r为键值等于5的组中的一个元素
                               select r;
                gv.DataSource = results2;
                gv.DataBind();
            }
        }
    }
   
    protected void BtnFuzzy_Click(object sender, EventArgs e)
    {
        mysqlDataContext db = new mysqlDataContext();
        var results = from r in db.info
                      where System.Data.Linq.SqlClient.SqlMethods.Like(r.name, "%fly%")
                      select r;
        gv.DataSource = results;
        gv.DataBind();
    }
}