﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data.Linq.SqlClient;
using System.Data;

public partial class 简历_login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label5.Text = Request.QueryString["id"];
        if (Request.Cookies["users"] != null)
        {
           Label4.Text= System.Web.HttpContext.Current.Server.UrlDecode(Request.Cookies["users"].Value)+ ",欢迎回来";
              
        }
        else
        {
            Response.Write("<script languge='javascript'>alert('请先注册'); window.location.href='register.aspx'</script>");

        }
    }
 

    protected void btnenter_Click(object sender, EventArgs e)
    {
        if (rdoltStatus.SelectedValue == "teacher")
        {
            //以查询字符串形式传递用户名信息并且被重定向到Teacher.aspx
            Response.Redirect("../简历/tec.aspx?tec=" + txtname.Text);
        }
        else
        {
            HttpCookie cookie = new HttpCookie("users");
            cookie.Value = txtname.Text;
            cookie.Expires = DateTime.Now.AddDays(1);
            Response.Cookies.Add(cookie);
            string strconn = "Server=tcp:35.database.windows.net,1433;Initial Catalog=Repo;Persist Security Info=False;User ID=jjfly;Password=233123321q@;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
            string strcmd = "select count(*) from info where name=N'" + txtname.Text + "' and pwd='" + Server.UrlEncode(txtpwd.Text) + "'";
            
            SqlConnection conn = new SqlConnection(strconn);
            SqlCommand cmd = new SqlCommand(strcmd, conn);
           
            conn.Open();
            int i = (int)cmd.ExecuteScalar();
            //int i = (int)cmd2.ExecuteScalar();
            if (i > 0)
            {
                
                Response.Redirect("../简历/personalresume.aspx?name1=" + txtname.Text+ "&&id=" + Label5.Text);
             
            }
            else
            {
                Response.Write("<script>alert('登录失败')</script>");
            }
            conn.Close();
        }
    }

    protected void btnreset_Click(object sender, EventArgs e)
    {
        txtname.Text = "";
        txtpwd.Text = "";
    }
 


    protected void regbutton_Click(object sender, EventArgs e)
    {
        Response.Redirect("../简历/register.aspx");
    }
}